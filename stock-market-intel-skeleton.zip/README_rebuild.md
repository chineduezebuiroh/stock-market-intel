# Stock Market Intel — Scaffold Rebuilder

This is a light scaffold bundle. To reconstruct the full project:

1. Unzip this folder into your local `stock-market-intel` repo directory.
2. In a terminal, from inside that directory, run:

   ```bash
   python rebuild_scaffold.py
   ```

3. This will create the full folder structure and all project files
   (app, etl, indicators, jobs, config, etc.).
