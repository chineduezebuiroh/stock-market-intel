# Stock Market Intel

Free-tier stock & futures screening with Streamlit + Parquet + GitHub Actions.

## Quick Start

1) **Create a virtual environment and install dependencies** (or run `./setup.sh` on macOS/Linux):
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2) **Local smoke test** (shortlists first):
```bash
python jobs/run_timeframe.py stocks daily --cascade
python jobs/run_timeframe.py stocks intraday_130m --cascade

python jobs/run_timeframe.py futures hourly --cascade
python jobs/run_timeframe.py futures four_hour --cascade
```

3) **Run the app**:
```bash
streamlit run app/main.py
```

## Deploy (GitHub + Streamlit)
- Push this repo to GitHub as `stock-market-intel`.
- In GitHub → Settings → Secrets → Actions, add:
  - `TELEGRAM_BOT_TOKEN`
  - `TELEGRAM_CHAT_ID`
  - *(optional)* `ALPHA_VANTAGE_KEY`
- Streamlit Community Cloud: point to `app/main.py` and add the same secrets if alerts should work from Streamlit too.

## Notes
- EOD uses yfinance.
- Intraday 130m is derived from 5m bars; futures use `=F` symbols (e.g., ES=F).
- Fixed windows per timeframe are defined in `config/timeframes.yaml`.
- Screening rules live in `config/screens/*.yaml`.
