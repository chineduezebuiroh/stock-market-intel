import pandas as pd
import numpy as np
from indicators.core import sma, ema, wema, rsi_wilder

def test_wema_generates_values():
    s = pd.Series(range(1, 101), dtype=float)
    out = wema(s, 14)
    assert not out.dropna().empty

def test_rsi_bounds():
    s = pd.Series(np.linspace(1, 2, 100))
    r = rsi_wilder(s, 14)
    assert r.max() <= 100 + 1e-6 and r.min() >= -1e-6
